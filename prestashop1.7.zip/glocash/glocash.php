<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class glocash extends PaymentModule {
	private $_postErrors = array();
    
    public $input_charset = "utf-8";
    public $transport = "http";
    public $logFile = "gc_response.log";	
	
    const V15 = '15';

    const V16 = '16';

    const V17 = '17';
    
    /**
     * 构造器
     */
    public function __construct() {

        $this->name = 'glocash';
        $this->tab = 'payments_gateways';
        $this->version = '1.1';
        $this->author = 'Glocash';
		
		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
		$this->controllers = array('payment','accept');

        parent::__construct();

        //$this->page = basename(__FILE__, '.php');
        $this->displayName = $this->l('Glocash Payment');
        $this->description = $this->l('Accepts payments by Glocash Payment');
        $this->confirmUninstall = $this->l('Are you sure you want to delete your details ?');
    }

    /**
     * 安装模块
     * @return bool
     */
    public function install() {
		
		if (!parent::install()
            || !$this->registerHook('payment')
            || !$this->registerHook('paymentReturn')
        ) {
            return false;
        }
		
		if ($this->getPsVersion() === $this::V17) {
            if (!$this->registerHook('paymentOptions')) {
                return false;
            }
        }
		
		if (!$this->createTable()) {
            return false;
        }
		
		return true;
    }

    /**
     * 卸载模块
     * @return bool
     */
    public function uninstall() {
				
        return (
            parent::uninstall() AND
            $this->removeTable() AND
            Configuration::deleteByName('GLOCASH_MERCHANT_LONG_KEY') AND
            Configuration::deleteByName('GLOCASH_MERCHANT_EMAIL') AND
			Configuration::deleteByName('GLOCASH_TITLE') AND
			Configuration::deleteByName('GLOCASH_BIL_METHOD') AND
			Configuration::deleteByName('GLOCASH_BIL_CC3DS') AND
			Configuration::deleteByName('GLOCASH_TERMINAL') AND
            Configuration::deleteByName('GLOCASH_DEBUG_MODE') );
    }
    
	
	public function getContent()
    {
        $output = null;

        if (Tools::isSubmit('submit' . $this->name)) {
            $merchant_long_key = (string) Tools::getValue('GLOCASH_MERCHANT_LONG_KEY');
			$merchant_email = (string) Tools::getValue('GLOCASH_MERCHANT_EMAIL');
            if (empty($merchant_long_key)) {
                $output .= $this->displayError($this->l('ApiKey is required. If you don\'t have one please contact glocash!'));
            }
			else if (empty($merchant_email)) {
                $output .= $this->displayError($this->l('Merchant_email is required. If you don\'t have one please contact glocash!'));
            } 
			else {
                Configuration::updateValue('GLOCASH_MERCHANT_LONG_KEY', Tools::getValue('GLOCASH_MERCHANT_LONG_KEY'));
                Configuration::updateValue('GLOCASH_MERCHANT_EMAIL', Tools::getValue('GLOCASH_MERCHANT_EMAIL'));
                Configuration::updateValue('GLOCASH_DEBUG_MODE', Tools::getValue('GLOCASH_DEBUG_MODE'));
				Configuration::updateValue('GLOCASH_TITLE', Tools::getValue('GLOCASH_TITLE'));
				Configuration::updateValue('GLOCASH_BIL_METHOD', Tools::getValue('GLOCASH_BIL_METHOD'));
                Configuration::updateValue('GLOCASH_BIL_CC3DS', Tools::getValue('GLOCASH_BIL_CC3DS'));
				Configuration::updateValue('GLOCASH_TERMINAL', Tools::getValue('GLOCASH_TERMINAL'));

                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }

        return $output . $this->displayForm();
    }
	
	private function displayForm(){
		
		$default_lang = (int) Configuration::get('PS_LANG_DEFAULT');
		
		$sandbox_options = array(
            array( 'id' => 'active_on', 'value' => 1, 'label' => 'Yes'),
            array( 'id' => 'active_off', 'value' => 0, 'label' => 'No'),
        );
				
        $terminal_options = array(
            array( 'type' => 'glocashpayment', 'name' => 'glocash payment'),
            array( 'type' => 'glocash', 'name' => 'glocash'),
        );
		
		$fields_form = array();
		
		$fields_form[0]['form'] = array(
			'legend' => array(
                'title' => 'Settings',
            ),
			'input' => array(
				array(
                    'type' => 'text',
                    'label' => 'Merchant_email',
                    'name' => 'GLOCASH_MERCHANT_EMAIL',
                    'size' => 50,
                    'required' => true,
                ),
				array(
                    'type' => 'text',
                    'label' => 'Secret_key',
                    'name' => 'GLOCASH_MERCHANT_LONG_KEY',
                    'size' => 100,
                    'required' => true,
                ),
				array(
                    'type' => 'text',
                    'label' => 'Method',
                    'name' => 'GLOCASH_BIL_METHOD',
                    'size' => 10,
                    'required' => true,
					'value'=>'C01',
                ),
				array(
                    'type' => 'switch',
                    'label' => '3DS',
                    'name' => 'GLOCASH_BIL_CC3DS',
                    'is_bool' => true,
                    'required' => false,
                    'values' => $sandbox_options,
                ),
				array(
                    'type' => 'switch',
                    'label' => 'Sandbox',
                    'name' => 'GLOCASH_DEBUG_MODE',
                    'is_bool' => true,
                    'required' => false,
                    'values' => $sandbox_options,
                ),
				array(
                    'type' => 'text',
                    'label' => 'Payment method title',
                    'name' => 'GLOCASH_TITLE',
                    'size' => 100,
                    'required' => false,
                ),
				array(
                    'type' => 'select',
                    'label' => 'Terminal',
                    'name' => 'GLOCASH_TERMINAL',
					'required' => true,
                    'options' => array(
                        'query' => $terminal_options,
                        'id' => 'type',
                        'name' => 'name',
                    ),
                ),
			),
			'submit' => array(
                'title' => 'Save',
                'class' => 'button',
            ),
		);
		
		
        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;

        // Language
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;

        // Title and toolbar
        $helper->title = $this->displayName . ' v' . $this->version;
        $helper->show_toolbar = true;        // false -> remove toolbar
        $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
        $helper->submit_action = 'submit' . $this->name;
        $helper->toolbar_btn = array(
            'save' => array(
                'desc' => $this->l('Save'),
                'href' => AdminController::$currentIndex . '&configure=' . $this->name . '&save' . $this->name .
                '&token=' . Tools::getAdminTokenLite('AdminModules'),
            ),
            'back' => array(
                'href' => AdminController::$currentIndex . '&token=' . Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Back to list'),
            ),
        );
		
		
		$helper->fields_value['GLOCASH_MERCHANT_LONG_KEY'] = Configuration::get('GLOCASH_MERCHANT_LONG_KEY');
        $helper->fields_value['GLOCASH_MERCHANT_EMAIL'] = Configuration::get('GLOCASH_MERCHANT_EMAIL');
        $helper->fields_value['GLOCASH_DEBUG_MODE'] = Configuration::get('GLOCASH_DEBUG_MODE');
		$helper->fields_value['GLOCASH_TITLE'] = Configuration::get('GLOCASH_TITLE');
        $helper->fields_value['GLOCASH_BIL_METHOD'] = Configuration::get('GLOCASH_BIL_METHOD');
        $helper->fields_value['GLOCASH_BIL_CC3DS'] = Configuration::get('GLOCASH_BIL_CC3DS');
		$helper->fields_value['GLOCASH_TERMINAL'] = Configuration::get('GLOCASH_TERMINAL');
		
		$html = '<div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7 ">'.$helper->generateForm($fields_form).'</div>
                    <div class="hidden-xs hidden-sm col-md-5 col-lg-5"></div>
                 </div>'.'<div class="row visible-xs visible-sm">
                   <div class="col-xs-12 col-sm-12"></div></div>';
        return $html;
		
	}
	

	
    /**
     * Hook payment options for Prestashop before 1.7.
     *
     * @param mixed $params
     *
     * @return mixed
     */
    public function hookPayment($params){

		if (!$this->active) {
            return;
        }
		
		$cart = $params['cart'];
		
		$customer = new Customer((int)($cart->id_customer));
		$currency = new Currency((int)($cart->id_currency));
		$currency = $currency->iso_code;
		$currency = strtoupper($currency);
				
		$amount=$cart->getOrderTotal(true, Cart::BOTH);
		
		$paymentData = array(
			'REQ_EMAIL' => Configuration::get('GLOCASH_MERCHANT_EMAIL'),
			'CUS_EMAIL'=>$customer->email,
			'BIL_PRICE'=>$amount,
			'BIL_CURRENCY'=>$currency,
			'CAID'=>base64_encode($cart->id),
			'paymentUrl' => (Configuration::get('PS_SSL_ENABLED') ? 'https://' : 'http://') . htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT, 'UTF-8') . __PS_BASE_URI__ . 'modules/' . $this->name . '/lib/payment.php',
        );
		
		$paymentData['SIGN'] = hash("sha256",
                Configuration::get('GLOCASH_MERCHANT_LONG_KEY').
                $paymentData['REQ_EMAIL'].
				$paymentData['CUS_EMAIL'].
                $paymentData['BIL_PRICE'].
                $paymentData['BIL_CURRENCY'].
				$paymentData['CAID']
        );

        $this->context->smarty->assign($paymentData);
		
        if ($this->getPsVersion() === $this::V16) {
            return $this->display(__FILE__, 'payment16.tpl');
        } else {
            return $this->display(__FILE__, 'payment.tpl');
        }
		
    }
	
	    /**
     * Hook payment options for Prestashop 1.7.
     *
     * @param mixed $params
     *
     * @return PrestaShop\PrestaShop\Core\Payment\PaymentOption[]
     */
    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }
        $cart = $params['cart'];

        $paymentInfoData = array(
			'MerchantEmail' => Configuration::get('GLOCASH_MERCHANT_EMAIL'),
        );
		
        $this->context->smarty->assign($paymentInfoData);

        $callToActionText = Tools::strlen(Configuration::get('GLOCASH_TITLE')) > 0 ? Configuration::get('GLOCASH_TITLE') : 'GLOCASH';

        $payPaymentOption = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
        $payPaymentOption->setCallToActionText($callToActionText)
            ->setAction($this->context->link->getModuleLink($this->name, 'payment', array(), true))
            ->setAdditionalInformation($this->context->smarty->fetch('module:glocash/views/templates/front/paymentinfo.tpl'));

        $paymentOptions = array();
        $paymentOptions[] = $payPaymentOption;

        return $paymentOptions;
    }


	public function hookPaymentReturn($params) {
	    
		
		$this->gcDbLog(0, "hookPaymentReturn POST:".json_encode($_POST));
		$this->gcDbLog(0, "hookPaymentReturn GET:".json_encode($_GET));
		$this->gcDbLog(0, "hookPaymentReturn params:".json_encode($params));
	    
		$payStatus="pending";
		if(!empty($param['BIL_STATUS'])){
			$payStatus=$param['BIL_STATUS'];
		}
		
		
	    $this->context->smarty->assign('payStatus', $payStatus);
	    return $this->display(__FILE__, 'confirmation.tpl');

    }

    public function excutePayment($params) {
		
		
		if(empty($_POST)){
			return $this->l('Payment failed');
		}
		
		$SIGN = hash("sha256",
                Configuration::get('GLOCASH_MERCHANT_LONG_KEY').
                Configuration::get('GLOCASH_MERCHANT_EMAIL').
				$_POST['CUS_EMAIL'].
                $_POST['BIL_PRICE'].
                $_POST['BIL_CURRENCY'].
				$_POST['CAID']
        );
		if(empty($_POST['SIGN']) || $SIGN!=$_POST['SIGN']){
			return $this->l('request failed');
		}
		
		$orderId = base64_decode($_POST['CAID']);
		$this->gcDbLog($orderId, "payment:".json_encode($_POST));
				
		//1.6创建订单	
		try {
			if ($this->getPsVersion() === $this::V16) {
				$this->validateOrder($orderId, Configuration::get('PS_OS_PREPARATION'), $_POST["BIL_PRICE"], $this->displayName, $this->l("Waiting for payment"));
				$order = new Order($this->currentOrder);
				$orderId = $this->currentOrder;
				$this->gcDbLog($orderId, "create ps order 16");
			}
		} catch (Exception $ex) {
			$message = 'Prestashop threw an exception on validateOrder: ' . $ex->getMessage();
			Tools::redirect($this->context->link->getModuleLink($this->name, 'accept', array(), true)."?fail=1&REQ_ERROR=".$message);
		}
		
		$orderIds = "PS".$orderId;
		

        //这里生成url需要的各种参数呗
        $param= array(
                'REQ_TIMES'=>time(),
                'REQ_EMAIL'=> Configuration::get('GLOCASH_MERCHANT_EMAIL'),
                'REQ_INVOICE'=> $orderIds,
                'CUS_EMAIL'=>$_POST["CUS_EMAIL"],
                'BIL_PRICE'=>$_POST["BIL_PRICE"],
                'BIL_CURRENCY'=>$_POST["BIL_CURRENCY"],
                'BIL_METHOD'=>Configuration::get('GLOCASH_BIL_METHOD'),
				'BIL_CC3DS'=>Configuration::get('GLOCASH_BIL_CC3DS'),
				'REQ_SANDBOX'=>Configuration::get('GLOCASH_DEBUG_MODE'),
                'URL_SUCCESS'=>$this->context->link->getModuleLink($this->name, 'accept', array(), true)."?id_cart=".$orderIds."&amount=".$_POST["BIL_PRICE"],
                'URL_PENDING'=>$this->context->link->getModuleLink($this->name, 'accept', array(), true)."?id_cart=".$orderIds."&amount=".$_POST["BIL_PRICE"],
                'URL_FAILED'=>$this->context->link->getModuleLink($this->name, 'accept', array(), true)."?fail=1",
                'URL_NOTIFY'=>$this->context->link->getModuleLink($this->name, 'callback', array(), true),
                'BIL_GOODSNAME'=>'',// 展示在付款页面的商品描述
        );
        
        $param['REQ_SIGN'] = hash("sha256",
                Configuration::get('GLOCASH_MERCHANT_LONG_KEY').
                $param['REQ_TIMES'].
                $param['REQ_EMAIL'].
                $param['REQ_INVOICE'].
                $param['CUS_EMAIL'].
                $param['BIL_METHOD'].
                $param['BIL_PRICE'].
                $param['BIL_CURRENCY']
        );
        
        if(!Configuration::get('GLOCASH_DEBUG_MODE')){
            $gatewayUrl = "https://pay.".Configuration::get('GLOCASH_TERMINAL').".com/";
        }else{
            $gatewayUrl = "https://sandbox.".Configuration::get('GLOCASH_TERMINAL').".com/";
        }

        
        $gatewayUrl .= "gateway/payment/index";
        $this->gcLog("excutePayment get url param:".json_encode($param));
		$this->gcDbLog($orderId, "excutePayment get url param:".json_encode($param));
        
        $httpCode = $this->paycurl($gatewayUrl, http_build_query($param), $result);
        $data = json_decode($result, true);
        $this->gcLog("excutePayment paycurl:".json_encode($data));
		$this->gcDbLog($orderId, "excutePayment paycurl:".json_encode($data));
        
        if ($httpCode!=200 || empty($data['URL_PAYMENT'])) {
            // 请求失败
			Tools::redirect($this->context->link->getModuleLink($this->name, 'accept', array(), true)."?fail=1&REQ_ERROR=".$data['REQ_ERROR']);
        }
		
		//$data['URL_PAYMENT']=str_replace("https","http",$data['URL_PAYMENT']);
        
        Tools::redirect($data['URL_PAYMENT']);
    }
    
    
    public function createTable()
    {
		$query='CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'glocash_log` (
			`id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
            `id_order` varchar(50) NOT NULL,
            `message` text NOT NULL,
            `date_add` datetime NOT NULL,
            PRIMARY KEY (`id_log`),
            KEY `id_order` (`id_order`)
			) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8';
		
        if (!Db::getInstance()->Execute($query)) {
            return false;
        }
		
		return true;
    }
    
    public function removeTable()
    {
        return Db::getInstance()->Execute('
			DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'glocash_log`');
    }
    
    // 验证 付款结果/PSN 提交的REQ_SIGN 是否合法
    public function validatePSNSIGN($param){
        // REQ_SIGN = SHA256 ( SECRET_KEY + REQ_TIMES + REQ_EMAIL + CUS_EMAIL + TNS_GCID + BIL_STATUS + BIL_METHOD + PGW_PRICE + PGW_CURRENCY )
        $sign = hash("sha256",
                Configuration::get('GLOCASH_MERCHANT_LONG_KEY').
                $param['REQ_TIMES'].
                Configuration::get('GLOCASH_MERCHANT_EMAIL').
                $param['CUS_EMAIL'].
                $param['TNS_GCID'].
                $param['BIL_STATUS'].
                $param['BIL_METHOD'].
                $param['PGW_PRICE'].
                $param['PGW_CURRENCY']
        );
		
    
        $this->gcLog(__FUNCTION__." sign:".$sign);
		$this->gcDbLog(0, "sign:".$sign);
        
        return $sign==$param['REQ_SIGN'];
    }
    
    
    /**
     * 支付curl提交
     * @param $url
     * @param $postData
     * @param $result
     * akirametero
     */
    private function paycurl( $url, $postData, &$result ){
        $options = array();
        if (!empty($postData)) {
            $options[CURLOPT_CUSTOMREQUEST] = 'POST';
            $options[CURLOPT_POSTFIELDS] = $postData;
        }
        $options[CURLOPT_USERAGENT] = 'Glocash/v2.*/CURL';
        $options[CURLOPT_ENCODING] = 'gzip,deflate';
        $options[CURLOPT_HTTPHEADER] = [
                'Accept: text/html,application/xhtml+xml,application/xml',
                'Accept-Language: en-US,en',
                'Pragma: no-cache',
                'Cache-Control: no-cache'
        ];
        $options[CURLOPT_RETURNTRANSFER] = 1;
        $options[CURLOPT_HEADER] = 0;
        if (substr($url,0,5)=='https') {
            $options[CURLOPT_SSL_VERIFYPEER] = false;
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $httpCode;
    }
    
    
    public function gcLog($message){
        $logger = new FileLogger(0); //0 == debug level, logDebug() won’t work without this.
        $logger->setFilename(_PS_ROOT_DIR_."/modules/" . $this->name . "/".$this->logFile);
        $logger->logDebug($message);
    }
    
    public function gcDbLog($orderId, $param){
        if(is_string($param)){
            $message = $param;
        }else{
            $message = json_encode($param);
        }
        
        
        $insertData = array(
            'id_order' => (int)$orderId,
            'date_add' => date("Y-m-d H:i:s", time()),
            'message' => pSQL($message)
        );
        
        Db::getInstance()->insert('glocash_log', $insertData, false, true);
        
    }
	
	
	/**
     * Get Ps Version.
     *
     * @return string
     */
    public function getPsVersion()
    {
        if (_PS_VERSION_ < '1.6.0.0') {
            return $this::V15;
        } elseif (_PS_VERSION_ >= '1.6.0.0' && _PS_VERSION_ < '1.7.0.0') {
            return $this::V16;
        } else {
            return $this::V17;
        }
    }
    
}
?>
