<?php
include 'baseaction.php';
include(dirname(__FILE__).'/glocash.php');

class GlocashAcceptModuleFrontController extends BaseAction
{
    /**
     * @see FrontController::postProcess()
     */
    public function postProcess()
    {
        $message = '';
        $responseCode = '400';
        $cart = null;
		
		$glocash = new glocash();
		$r=array(
			'get'=>$_GET,
			'post'=>$_POST,
		);
		$glocash->gcDbLog(0,json_encode($r));

		if (!Tools::getIsset('fail')) {
			if ($this->validateAction(false, $message, $cart)) {
				$this->redirectToAccept($cart);
			} else {
				$message = empty($message) ? $this->l('Unknown error') : $message;
				$this->handleError($message, $cart);
			}
		}
		else{
			$message='Order failed or cancel. If you think this is an error, you can contact our';			
			if (Tools::getIsset('REQ_ERROR')) {
				$message=Tools::getValue('REQ_ERROR');
			}
			$this->handleError($message, $cart);
		}

    }

    /**
     * Redirect To Accept.
     *
     * @param mixed $cart
     */
    private function redirectToAccept($cart)
    {
        Tools::redirectLink(__PS_BASE_URI__ . 'order-confirmation.php?key=' . $cart->secure_key . '&id_cart=' . (int) $cart->id . '&id_module=' . (int) $this->module->id . '&id_order=' . (int) Order::getOrderByCartId($cart->id));
    }

    private function handleError($message, $cart)
    {
		$glocash = new glocash();
		$glocash->gcDbLog(0,$message);
		
        Context::getContext()->smarty->assign('paymenterror', $message);
        if ($this->module->getPsVersion() === glocash::V17) {
            $this->setTemplate('module:glocash/views/templates/front/paymenterror17.tpl');
        } else {
            $this->setTemplate('paymenterror.tpl');
        }
    }
}
