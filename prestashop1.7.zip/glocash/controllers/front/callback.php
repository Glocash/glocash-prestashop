<?php
include 'baseaction.php';
include(dirname(__FILE__).'/glocash.php');

class GlocashCallbackModuleFrontController extends BaseAction
{
    /**
     * @see FrontController::postProcess()
     */
    public function postProcess()
    {
        $message = '';
        $responseCode = 400;
        $cart = null;
		
		$glocash = new glocash();
		
		$param = $_POST;
		
		if (!$param['TNS_GCID']) {
            $message = 'No TNS_GCID was supplied to the system!';
            $glocash->gcDbLog(0,json_encode($_POST));
			return ;
        }
		
		$orderId = $param['REQ_INVOICE'];
		$glocash->gcDbLog($orderId,json_encode($param));
		
		$valid = false;
		try {
			$valid = $glocash->validatePSNSIGN($param);
		}catch (Exception $e){
			$glocash->gcDbLog($orderId,$e->getMessage());
		}
		
		if(!$valid){
			$glocash->gcDbLog($orderId,"notify validate params fail.");
			header([], true,200);
			return ;
		}
		
		
		try{
			$prefix = '[INFO] ';
			$payStatus = $param['BIL_STATUS'];
			$comment = "BIL_STATUS {$payStatus}, PGW_MESSAGE:".$param['PGW_MESSAGE'];
			
			$order_status = null;
			switch ($payStatus) {
				case 'paid':
					$order_status = _PS_OS_PAYMENT_;
					break;
				case 'pending':
					$order_status = _PS_OS_PAYMENT_;
					break;
				case "unpaid":
					$order_status = _PS_OS_PREPARATION_;
					break;
				case "failed":
					$prefix = '[ERROR] ';
					$order_status = _PS_OS_ERROR_;
					break;
				default:
					$prefix = '[ERROR] ';
					$order_status = _PS_OS_ERROR_;
					break;
			}
			
			$id_cart = substr($orderId,2); 

			$order = new Order((int)Order::getOrderByCartId($id_cart));
			$new_history = new OrderHistory();
			$new_history->id_order = (int)$order->id;

			$new_history->changeIdOrderState((int)$order_status, $order, true);
			$new_history->addWithemail(true);
			
			$glocash->gcDbLog($orderId, $prefix.$comment);
			$glocash->gcDbLog($orderId, "[INFO] changed order status success.");
			
			
		}catch (Exception $e){
			$glocash->gcDbLog($orderId,$e->getMessage());
			header([], true,200);
			return;
		}
		

		header([], true,200);
        die($message);
    }
}
