<?php

class GlocashPaymentModuleFrontController extends ModuleFrontController
{
    /**
     * @see FrontController::postProcess()
     */
    public function postProcess()
    {

        $cart = $this->context->cart;
        if ($cart->id_customer == 0 ||
            $cart->id_address_delivery == 0 ||
            $cart->id_address_invoice == 0 ||
            !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        $authorized = false;
        foreach (Module::getPaymentModules() as $module) {
            if ($module['name'] == 'glocash') {
                $authorized = true;
                break;
            }
        }

        if (!$authorized) {
            die($this->module->l('This payment method is not available.', 'glocash'));
        }
		
		$customer = new Customer((int)($cart->id_customer));
		$currency = new Currency((int)($cart->id_currency));
		$currency = $currency->iso_code;
		$currency = strtoupper($currency);
				
		$amount=$cart->getOrderTotal(true, Cart::BOTH);
		
		//创建订单
		if ($this->module->getPsVersion() === glocash::V17) {
			try {
				$this->module->validateOrder(
					(int) $cart->id,
					Configuration::get('PS_OS_PREPARATION'),
					$amount,
					$module['name'],
					null,
					[],
					null,
					false,
					$cart->secure_key
				);
			} catch (Exception $ex) {
				$message = 'Prestashop threw an exception on validateOrder: ' . $ex->getMessage();
				Context::getContext()->smarty->assign('paymenterror', $message);
				$this->setTemplate('module:glocash/views/templates/front/paymenterror17.tpl');
			}
		}

		$id_order = Order::getOrderByCartId($cart->id);
		$this->module->gcDbLog($id_order, "create ps order 17");
		$order = new Order($id_order);
		$payment = $order->getOrderPayments();
		$payment[0]->save();
		
		$paymentData = array(
			'REQ_EMAIL' => Configuration::get('GLOCASH_MERCHANT_EMAIL'),
			'CUS_EMAIL'=>$customer->email,
			'BIL_PRICE'=>$amount,
			'BIL_CURRENCY'=>$currency,
			'CAID'=>base64_encode($cart->id),
			'paymentUrl' => (Configuration::get('PS_SSL_ENABLED') ? 'https://' : 'http://') . htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT, 'UTF-8') . __PS_BASE_URI__ . 'modules/' . $module['name'] . '/lib/payment.php',
        );
		
		$paymentData['SIGN'] = hash("sha256",
                Configuration::get('GLOCASH_MERCHANT_LONG_KEY').
                $paymentData['REQ_EMAIL'].
				$paymentData['CUS_EMAIL'].
                $paymentData['BIL_PRICE'].
                $paymentData['BIL_CURRENCY'].
				$paymentData['CAID']
        );

        $this->context->smarty->assign($paymentData);

		$this->setTemplate('module:glocash/views/templates/front/payment.tpl');
		
        
    }
}
