<?php

abstract class BaseAction extends ModuleFrontController
{
    /**
     * Validate the callback.
     *
     * @param bool $isPaymentRequest
     * @param string $message
     * @param mixed $cart
     *
     * @return bool
     */
    protected function validateAction($isPaymentRequest, &$message, &$cart)
    {
        /*if (!Tools::getIsset('merchantOrderID')) {
            $message = 'No GET(merchantOrderID) was supplied to the system!';
            return false;
        }*/

        $id_cart = null;

		if (!Tools::getIsset('id_cart')) {
			$message = 'No Cart id was supplied on the paymentrequest callback';
			return false;
		}
		$id_cart = Tools::getValue('id_cart');
		$id_cart = substr($id_cart,2); 

        $cart = new Cart($id_cart);

        if (!isset($cart->id)) {
            $message = 'Please provide a valid orderid or cartid';
            return false;
        }

        return true;
    }

}
